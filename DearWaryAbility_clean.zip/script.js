let currentInvoiceType = 'sales';

// Wait for DOM to load before adding event listeners
document.addEventListener('DOMContentLoaded', function() {
  const darkToggle = document.getElementById('darkModeToggle');
  if (darkToggle) {
    darkToggle.addEventListener('change', () => document.body.classList.toggle('dark', darkToggle.checked));
  }
  
  // Add initial item row
  addItem();
});

// Customer ledger storage
let customerLedger = JSON.parse(localStorage.getItem('customerLedger')) || [];

function setInvoiceType(type) {
  currentInvoiceType = type;
  document.getElementById('invoiceTypeLabel').innerText =
    type === 'sales' ? 'Sales Invoice' : 'Purchase Invoice';
}

function addItem() {
  const row = document.createElement('tr');
  row.innerHTML = `
    <td><input class="item-name" type="text" /></td>
    <td><input class="item-qty" type="number" value="1" min="1" /></td>
    <td><input class="item-rate" type="number" value="0" min="0" /></td>
    <td class="item-total">0.00</td>
    <td><button onclick="removeItem(this)">Clear </button></td>
  `;
  document.getElementById('itemTableBody').appendChild(row);
  row.querySelectorAll('input').forEach(input => input.addEventListener('input', updateTotals));
  updateTotals();
}

function removeItem(btn) {
  btn.closest('tr').remove();
  updateTotals();
}

function updateTotals() {
  let subtotal = 0;
  document.querySelectorAll('#itemTableBody tr').forEach(row => {
    const qty = +row.querySelector('.item-qty').value;
    const rate = +row.querySelector('.item-rate').value;
    const tot = qty * rate;
    row.querySelector('.item-total').innerText = tot.toFixed(2);
    subtotal += tot;
  });
  const gst = subtotal * (+document.getElementById('gstPercent').value) / 100;
  document.getElementById('gstAmount').innerText = gst.toFixed(2);
  document.getElementById('finalTotal').innerText = (subtotal + gst).toFixed(2);
}

function generateInvoice() {
  const no = document.getElementById('invoiceNumber').value;
  const dt = document.getElementById('invoiceDate').value;
  const name = document.getElementById('customerName').value;
  const contact = document.getElementById('customerContact').value;
  const gst = document.getElementById('gstAmount').innerText;
  const total = document.getElementById('finalTotal').innerText;

  let html = `<h3>${currentInvoiceType.toUpperCase()} INVOICE</h3>
    <p><strong>No:</strong> ${no}</p>
    <p><strong>Date:</strong> ${dt}</p>
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Contact:</strong> ${contact}</p>
    <table><tr><th>Item</th><th>Qty</th><th>Rate</th><th>Total</th></tr>`;

  document.querySelectorAll('#itemTableBody tr').forEach(row => {
    html += `<tr>
      <td>${row.querySelector('.item-name').value}</td>
      <td>${row.querySelector('.item-qty').value}</td>
      <td>${row.querySelector('.item-rate').value}</td>
      <td>${row.querySelector('.item-total').innerText}</td>
    </tr>`;
  });

  html += `</table><p>GST: ₹${gst}</p><p><strong>Total: ₹${total}</strong></p>`;
  document.getElementById('invoiceOutput').innerHTML = html;

  // Auto-create ledger entry
  if (name && total && parseFloat(total) > 0) {
    addLedgerEntry(name, contact, no, dt, parseFloat(total), currentInvoiceType);
  }
}

function printInvoice() {
  generateInvoice();
  const w = window.open('', '_blank', 'width=800,height=600');
  w.document.write(document.getElementById('invoiceOutput').outerHTML);
  w.document.close();
  w.print();
}

function downloadPDF() {
  generateInvoice();
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  
  const no = document.getElementById('invoiceNumber').value || 'N/A';
  const dt = document.getElementById('invoiceDate').value || 'N/A';
  const name = document.getElementById('customerName').value || 'N/A';
  const contact = document.getElementById('customerContact').value || 'N/A';
  const gst = document.getElementById('gstAmount').innerText;
  const total = document.getElementById('finalTotal').innerText;
  
  // Add header
  doc.setFontSize(20);
  doc.text('Shiv Balaji Trading Company', 20, 20);
  
  doc.setFontSize(16);
  doc.text(`${currentInvoiceType.toUpperCase()} INVOICE`, 20, 35);
  
  // Add invoice details
  doc.setFontSize(12);
  doc.text(`Invoice No: ${no}`, 20, 50);
  doc.text(`Date: ${dt}`, 20, 60);
  doc.text(`Customer: ${name}`, 20, 70);
  doc.text(`Contact: ${contact}`, 20, 80);
  
  // Add table header
  let yPosition = 100;
  doc.text('Item', 20, yPosition);
  doc.text('Qty', 80, yPosition);
  doc.text('Rate', 120, yPosition);
  doc.text('Total', 160, yPosition);
  
  // Add line under header
  doc.line(20, yPosition + 5, 190, yPosition + 5);
  yPosition += 15;
  
  // Add items
  document.querySelectorAll('#itemTableBody tr').forEach(row => {
    const itemName = row.querySelector('.item-name').value || '';
    const qty = row.querySelector('.item-qty').value || '0';
    const rate = row.querySelector('.item-rate').value || '0';
    const itemTotal = row.querySelector('.item-total').innerText || '0.00';
    
    doc.text(itemName, 20, yPosition);
    doc.text(qty, 80, yPosition);
    doc.text(rate, 120, yPosition);
    doc.text(itemTotal, 160, yPosition);
    yPosition += 10;
  });
  
  // Add totals
  yPosition += 10;
  doc.line(20, yPosition, 190, yPosition);
  yPosition += 10;
  doc.text(`GST: ₹${gst}`, 120, yPosition);
  yPosition += 10;
  doc.setFontSize(14);
  doc.text(`Total: ₹${total}`, 120, yPosition);
  
  // Save the PDF
  const fileName = `${currentInvoiceType}_invoice_${no || 'draft'}.pdf`;
  doc.save(fileName);
}

function shareToWhatsApp() {
  generateInvoice();
  
  const no = document.getElementById('invoiceNumber').value || 'N/A';
  const dt = document.getElementById('invoiceDate').value || 'N/A';
  const name = document.getElementById('customerName').value || 'N/A';
  const contact = document.getElementById('customerContact').value || 'N/A';
  const gst = document.getElementById('gstAmount').innerText;
  const total = document.getElementById('finalTotal').innerText;
  
  let message = `*${currentInvoiceType.toUpperCase()} INVOICE*\n\n`;
  message += `🏢 *Shiv Balaji Trading Company*\n\n`;
  message += `📋 Invoice No: ${no}\n`;
  message += `📅 Date: ${dt}\n`;
  message += `👤 Customer: ${name}\n`;
  message += `📞 Contact: ${contact}\n\n`;
  message += `*ITEMS:*\n`;
  
  document.querySelectorAll('#itemTableBody tr').forEach((row, index) => {
    const itemName = row.querySelector('.item-name').value || '';
    const qty = row.querySelector('.item-qty').value || '0';
    const rate = row.querySelector('.item-rate').value || '0';
    const itemTotal = row.querySelector('.item-total').innerText || '0.00';
    
    if (itemName) {
      message += `${index + 1}. ${itemName}\n`;
      message += `   Qty: ${qty} × ₹${rate} = ₹${itemTotal}\n\n`;
    }
  });
  
  message += `💰 GST: ₹${gst}\n`;
  message += `*💸 Total: ₹${total}*\n\n`;
  message += `Thank you for your business! 🙏`;
  
  const encodedMessage = encodeURIComponent(message);
  const whatsappURL = `https://wa.me/?text=${encodedMessage}`;
  
  window.open(whatsappURL, '_blank');
}

function addLedgerEntry(customerName, contact, invoiceNo, date, amount, type) {
  const entry = {
    id: Date.now(),
    customerName: customerName.trim(),
    contact: contact || '',
    invoiceNo: invoiceNo || '',
    date: date || new Date().toISOString().split('T')[0],
    debit: type === 'sales' ? amount : 0,
    credit: type === 'purchase' ? amount : 0,
    type: type,
    timestamp: new Date().toISOString()
  };
  
  customerLedger.push(entry);
  localStorage.setItem('customerLedger', JSON.stringify(customerLedger));
}

function showLedger() {
  const filter = document.getElementById('ledgerCustomerFilter').value.toLowerCase();
  const filteredEntries = customerLedger.filter(entry => 
    !filter || entry.customerName.toLowerCase().includes(filter)
  );
  
  // Group by customer and calculate running balance
  const customerBalances = {};
  
  filteredEntries.forEach(entry => {
    if (!customerBalances[entry.customerName]) {
      customerBalances[entry.customerName] = {
        contact: entry.contact,
        entries: [],
        totalDebit: 0,
        totalCredit: 0,
        balance: 0
      };
    }
    
    customerBalances[entry.customerName].entries.push(entry);
    customerBalances[entry.customerName].totalDebit += entry.debit;
    customerBalances[entry.customerName].totalCredit += entry.credit;
    customerBalances[entry.customerName].balance = 
      customerBalances[entry.customerName].totalDebit - customerBalances[entry.customerName].totalCredit;
  });
  
  let html = '<h4>Customer Ledger Report</h4>';
  
  Object.keys(customerBalances).forEach(customerName => {
    const customer = customerBalances[customerName];
    const balanceClass = customer.balance > 0 ? 'debit' : customer.balance < 0 ? 'credit' : '';
    
    html += `
      <div style="margin: 20px 0; padding: 15px; border: 1px solid var(--border); border-radius: 5px;">
        <h5>${customerName} ${customer.contact ? `(${customer.contact})` : ''}</h5>
        <p class="balance">Balance: ₹<span class="${balanceClass}">${Math.abs(customer.balance).toFixed(2)}</span> 
        ${customer.balance > 0 ? '(Receivable)' : customer.balance < 0 ? '(Payable)' : '(Settled)'}</p>
        
        <table class="ledger-table">
          <tr>
            <th>Date</th>
            <th>Invoice</th>
            <th>Type</th>
            <th>Debit</th>
            <th>Credit</th>
          </tr>`;
    
    customer.entries.sort((a, b) => new Date(a.date) - new Date(b.date)).forEach(entry => {
      html += `
        <tr>
          <td>${entry.date}</td>
          <td>${entry.invoiceNo}</td>
          <td>${entry.type}</td>
          <td class="debit">${entry.debit > 0 ? '₹' + entry.debit.toFixed(2) : '-'}</td>
          <td class="credit">${entry.credit > 0 ? '₹' + entry.credit.toFixed(2) : '-'}</td>
        </tr>`;
    });
    
    html += `
        <tr style="background: #f5f5f5; font-weight: bold;">
          <td colspan="3">Total</td>
          <td class="debit">₹${customer.totalDebit.toFixed(2)}</td>
          <td class="credit">₹${customer.totalCredit.toFixed(2)}</td>
        </tr>
      </table>
      </div>`;
  });
  
  if (Object.keys(customerBalances).length === 0) {
    html += '<p>No ledger entries found.</p>';
  }
  
  document.getElementById('ledgerOutput').innerHTML = html;
}

function clearLedger() {
  if (confirm('Are you sure you want to clear all ledger entries? This cannot be undone.')) {
    customerLedger = [];
    localStorage.removeItem('customerLedger');
    document.getElementById('ledgerOutput').innerHTML = '<p>Ledger cleared.</p>';
  }
}